package com.example.multipurposecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMI extends AppCompatActivity {
    EditText e1,e2,e3;
    TextView bmi;
    Button b1;
    Double res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
       // e1=(EditText) findViewById(R.id.weight);
        e2=(EditText) findViewById(R.id.weight);
        e3=(EditText) findViewById(R.id.height);
        bmi=(TextView) findViewById(R.id.BMI);
        b1=(Button) findViewById(R.id.button10);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double weight = Double.parseDouble(e2.getText().toString());
                    double height = Double.parseDouble(e3.getText().toString());

                    if (weight > 0 && height > 0) {
                        res = weight / (height * height);
                        // Format the result to two decimal places
                        bmi.setText(res.toString());
                    } else {
                        bmi.setText("Invalid input");
                    }
                } catch (NumberFormatException e) {
                    bmi.setText("Invalid input");
                }
            }
        });
    }
}